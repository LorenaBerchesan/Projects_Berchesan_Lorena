import math
import random



def start():
    exp = 10
    n = 50
    pop_size = 50
    d = 100

    print(f"exp: {exp}")
    print(f"nr iteratii: {n}")
    print(f"pop_size: {pop_size}")
    print(f"dimensiune: {d}")

    bestSol = [ ]
    best_sol = 0
    sum = 0


    for i in range(exp):
        solution = run(n, d, pop_size)
        f = total(solution, d)
        sum += f
        print(string_solution(solution, f))
        if f < best_sol:
            best_sol = f
            bestSol = solution


    print("BEST SOLUTION")
    print(string_solution(bestSol, best_sol))
    print(f"Best fitness: {best_sol}")
    print(f"Average fitness: {round(sum / exp, 4)}")
    print(f"Optimal fitness: {round(-d * 418.9829, 4)}")



def run(n, d, pop_size):
    populatie = [ ]
    for i in range(pop_size):
        populatie.append(generate_random_solution(d))

    for i in range(1, n):
        parinti = selectie_parinti(populatie, d, pop_size)
        copii = generare_copii(parinti, d, pop_size)
        mCopii = generareMCopii(parinti, d)
        p = parinti + copii + mCopii
        fp = [ ]
        for i in p:
            f = total(i, d)
            fp.append((i, f))

        fp.sort(key=lambda i: i [ 1 ])

        populatie = [ ]
        for j in range(pop_size):
            populatie.append(fp[ j ] [ 0 ])

    bestSol = [ ]
    best_fitness = 0

    for i in populatie:
        fitness = total(i, d)
        if fitness < best_fitness:
            best_fitness = fitness
            bestSol = i

    return bestSol


#

def selectie_parinti(population, d, pop_size):
    tfitness = 0
    fitnesses = [ ]
    for i in population:
        fitness = total(i, d)
        tfitness += fitness
        fitnesses.append(fitness)

    probabilites = [ fitness / tfitness for fitness in fitnesses ]
    cumulative_probabilites = [ ]
    for i in range(pop_size):
        qi = 0
        for j in range(i):
            qi += abs(probabilites [ j ])
        cumulative_probabilites.append(qi)

    return random.choices(population, cum_weights=cumulative_probabilites, k=pop_size)

#incurcisare cu medie completa
def generare_copii(parinte, d, pop_size):
    children = [ ]
    for i in range(pop_size):
        ps = random.sample(parinte, 2)
        child = [ ]
        for j in range(d):
            x = ps [ 0 ] [ j ]
            y = ps [ 1 ] [ j ]
            z = round((x + y) / 2, 4)
            child.append(z)

        children.append(child)

    return children

#mutatie uniforma
def generareMCopii(parinti, d):
    copii = [ ]
    for p in parinti:
        i = random.randint(0, d - 1)
        xi = round(random.uniform(-500, 500), 4)
        copil = p.copy()
        copil [ i ] = xi
        copii.append(copil)

    return copii



def generate_random_solution(d):
    solution = [ ]
    for i in range(d):
        xi = round(random.uniform(-500, 500), 4)
        solution.append(xi)

    return solution


def total(solution, d):
    sum = 0
    for i in range(d):
        xi = solution [ i ]
        isum = -xi * math.sin(math.sqrt(abs(xi)))

        sum += isum

    return round(sum, 4)

def string_solution(solution, fitness):
    return f"{solution} - fitness: {fitness}"



start()


