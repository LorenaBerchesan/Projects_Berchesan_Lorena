import math
import random



def start():
    exp = 10
    n = 100
    pop_size = 100
    d = 20

    print(f"exp: {exp}")
    print(f"Nr iteratii: {n}")
    print(f"pop_size: {pop_size}")
    print(f"dimensiune: {d}")

    bestSol = [ ]
    best_sol = 0
    sum = 0


    for i in range(exp):
        sol = run(n, d, pop_size)
        fitness = total(sol, d)
        sum += fitness
        print(string_solution(sol, fitness))
        if fitness < best_sol:
            best_sol = fitness
            bestSol = sol

    print("BEST SOLUTION")
    print(string_solution(bestSol, best_sol))
    print(f"Best fitness: {best_sol}")
    print(f"Average fitness: {round(sum / exp, 4)}")
    print(f"Optimal fitness: {round(-d * 418.9829, 4)}")


def run(n, d, pop_size):
    gbest = [ ]
    gbestF = 0
    population = [ ]
    velocities = [ ]
    personal_bests = [ ]
    personal_bests_fitnesses = [ ]

    w_max = 1
    w_min = 0
    w = w_max
    c1 = 2
    c2 = 2
    nk = round(pop_size * 0.1)

    for i in range(pop_size):
        x = generate_random_solution(d)
        fitness = total(x, d)
        population.append(x)
        velocities.append([ 0 ] * d)
        personal_bests.append(x)
        personal_bests_fitnesses.append(fitness)
        if fitness < gbestF:
            gbest_fitness = fitness
            gbest = x

    for i in range(pop_size):
        for j in range(d):
            sign = random.choice([ 1, -1 ])
            vi = (c1 * random.uniform(0, 1) * (personal_bests [ i ] [ j ] - population [ i ] [ j ])) + (
                        c2 * random.uniform(0, 1) * (gbest [ j ] - population [ i ] [ j ]))
            vi *= sign
            velocities [ i ] [ j ] = vi

    for k in range(n):
        replace_indexes = [ ]
        for i in range(nk):
            while True:
                ni = random.randint(0, pop_size - 1)
                if ni in replace_indexes:
                    continue
                else:
                    replace_indexes.append(ni)
                    break

        for i in replace_indexes:
            population [ i ] = generate_random_solution(d)

        for i in range(pop_size):
            for j in range(d):
                new_x = population [ i ] [ j ] + velocities [ i ] [ j ]
                if new_x < -500:
                    new_x = -500
                elif new_x > 500:
                    new_x = 500

                population [ i ] [ j ] = round(new_x, 2)

            for j in range(d):
                sign = 1
                if velocities [ i ] [ j ] < 0:
                    sign = -1
                vi = w * velocities [ i ] [ j ] + (
                            c1 * random.uniform(0, 1) * (personal_bests [ i ] [ j ] - population [ i ] [ j ])) + (
                                 c2 * random.uniform(0, 1) * (gbest [ j ] - population [ i ] [ j ]))
                vi *= sign
                velocities [ i ] [ j ] = vi

            w = w_max - (i / n) * (w_max - w_min)

            for j in range(pop_size):
                x = population [ j ]
                fitness = total(x, d)
                if fitness < personal_bests_fitnesses [ j ]:
                    personal_bests [ j ] = x
                    personal_bests_fitnesses [ j ] = fitness

                if fitness < gbest_fitness:
                    gbest_fitness = fitness
                    gbest = x

    return gbest


def generate_random_solution(d):
    solution = [ ]
    for i in range(d):
        xi = round(random.uniform(-500, 500), 4)
        solution.append(xi)

    return solution


def total(solution, d):
    sum = 0
    for i in range(d):
        xi = solution [ i ]
        isum = -xi * math.sin(math.sqrt(abs(xi)))
        sum += isum

    return round(sum, 4)


def string_solution(solution, fitness):
    return f"{solution} - fitness: {fitness}"


start()

