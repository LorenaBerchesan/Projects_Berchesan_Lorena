import random


class Rucsac:
    def __init__(self,filename):
        with open(filename,'r') as file:
            lines=file.readlines()
            self.size=lines[0]
            self.items=[line.split() for line in lines[1:-2]]
            self.cap=lines[-1]
        self.solution=[]

    def sirBinar(self,n):
        lista=[]
        i=0
        while i < n :
            lista.append(0)
            i=i+1
        return lista

    def randomEl(self,n):
        c = random.randint(0,n-1)
        return c

    def sumaGreutate(self,suma,element,w):

        if suma <= w:
            suma=suma+int(self.items[element][2])

        #else:
            #suma=suma-int(self.items[element][2])
        return suma

    def sumaValoare(self,suma,element):
        suma=suma+int(self.items[element][1])
        return suma

    def scadereSumaGR(self,suma,element):
        suma=suma-int(self.items[element][2])
        return suma

    def scadereSumaVAL(self,suma,element):
        suma=suma-int(self.items[element][1])
        return suma

    def rezolvareSuma(self,n,w):
        sumaGR = 0
        sumaVal = 0
        sirBinar = self.sirBinar(n)
        kk = 0
        while sumaGR <= w and kk == 0:
            element = self.randomEl(n)
            #print(element)
            #print(sirBinar)
            #print("len:",len(sirBinar))
            #if sirBinar[element] == 0 :
            if  element <n and sirBinar[element] == 0:#aici trb sa rezolv problema cu ultimul element
                #print(element)

                sirBinar[element]=1
                #print(sirBinar)
                #print("len:",len(sirBinar))
                element = element - 1
                sumaGR = self.sumaGreutate(sumaGR, element, w)
                sumaVal = self.sumaValoare(sumaVal, element)
                if sumaGR > w:
                    sumaGR = self.scadereSumaGR(sumaGR, element)
                    sumaVal = self.scadereSumaVAL(sumaVal, element)
                    kk=1
        return sumaGR,sumaVal

    def valMax(self,lista):
        lista.sort(reverse=True)
        return lista














