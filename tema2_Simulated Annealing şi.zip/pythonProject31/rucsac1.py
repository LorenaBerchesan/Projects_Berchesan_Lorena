import numpy as np
class Rucsac1:
    def __init__(self,filename):
        with open(filename,'r') as file:
            lines=file.readlines()
            self.size = lines[0]
            self.items=[]
            for line in lines[1:-1]:
                l = line.split()
                item =[int(l[0]), int(l[1]), int(l[2])]
                self.items.append(item)
            self.cap=lines[-1]
        self.solution=[]

    def generareGreutate(self,solutie,urmSol):
        greutate=0
        if urmSol!=0:
            solutie.append(urmSol)
        for i in solutie:
            greutate=greutate+ self.items[i][2]
        return greutate

    def generareGreutate2(self,solutie):
        greutate=0
        for i in solutie:
            greutate=greutate+ self.items[i][2]
        return greutate

    def generareValoare(self,solutie):
        valoare=0
        for i in solutie:
            valoare=valoare+self.items[i][1]
        return valoare

    def valMax(self,lista):
        lista.sort(reverse=True)
        return lista

    def nahc(self,k,max,r):
        listaVal=[]
        listaGr=[]
        i=0
        while i<k:
            solutie=self.generare_nahc(max,r)
            for s in range(2):
                val = self.generareValoare(solutie)
                listaVal.append(val)
                gr = self.generareGreutate2(solutie)
                listaGr.append(gr)
            i=i+1
        print("Lista valori:", listaVal)
        lista=self.valMax(listaVal)

        print("lista greutati:",listaGr)
        print("Cea mai buna valoare eeste:",lista[0])

    def generare_nahc(self,max,r):
        solutie = self.solution.copy()
        while True:
            sol = self.hill_climbing(max, r)
            if sol in solutie:
                continue
            greutate = self.generareGreutate(solutie.copy(),sol)
            if greutate > int(self.cap):
                break
            solutie.append(sol)
        return solutie

    def hill_climbing(self, max, r):
        lista = []
        for p in range(max):
            lista.append(self.hilltop(r))
        print("lista hiltop",lista)
        maxHT = 0
        maxHtVal = 0
        for hilltop in lista:
            htVal = int(self.items[hilltop][1])
            if htVal > maxHtVal:
                maxHtVal = htVal
                maxHT = hilltop
        return maxHT

    def verificareVecini(self, element, r):
        op = (element, self.items[element][2])
        for i, valoare, greutate in self.items:
            i=int(i)-1
            if i == element:
                continue
            dist = np.sqrt((int(valoare) - int(self.items[element][1])) ** 2 + (int(greutate) - int(self.items[element][2])) ** 2)
            if dist < r:
                diferenta = self.items[i][2]
                if diferenta < op[1]:
                    op = (i, diferenta)
                    break
        return op[0]

    def hilltop(self,r):
        element=np.random.randint(0,self.size)
        while True:
            copieEl = element
            element = self.verificareVecini(element, r)
            if copieEl == element:
                return element