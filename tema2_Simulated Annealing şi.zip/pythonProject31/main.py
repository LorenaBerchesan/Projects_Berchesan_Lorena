from rucsac import Rucsac
from rucsac1 import Rucsac1
from incercare2 import Rucsac3
from inc import Voiajor1




def meniu():
    print("1.Afisare rezultate pentru rucsac20")
    print("2.Afisare rezultate pentru rucsac200")
    print("3.Problema 2-rucsac20")
    print("4.Problema 2-rucsac200")
    print("5.Lab2-problema1")
    print("6.Lab2-problema2")
    print("X.Stop")

if __name__ == '__main__':
    while True:
        meniu()
        i=input("Insereaza comanda")
        if i=="1":
            rucsac=Rucsac("rucsac20")
            n = int(rucsac.size)
            w = int(rucsac.cap)  # greutate ghiozdan
            m = 10
            j = 1
            lista=[]
            while j <= m:
                sumaGR, sumaVal = rucsac.rezolvareSuma(n, w)
                lista.append(sumaVal)
                print("lista este:",lista)
                print("suma greutate:", sumaGR)
                print("suma valoare:", sumaVal)
                j=j+1
                lista=rucsac.valMax(lista)
                max=lista[0]
            print("Cea mai buna valoare este:",max)
        if i=='2':
            rucsac2 = Rucsac("rucsac200")
            n = int(rucsac2.size)
            w = int(rucsac2.cap)  # greutate ghiozdan
            m = 10
            j = 1
            sumaGR = 0
            sumaVal = 0
            lista=[]
            while j <= m:
                sumaGR, sumaVal = rucsac2.rezolvareSuma(n, w)
                lista.append(sumaVal)
                print("suma greutate:", sumaGR)
                print("suma valoare:", sumaVal)
                print("suma valoare:", sumaVal)
                j = j + 1
            lista = rucsac2.valMax(lista)
            max = lista[0]

            print("Cea mai buna valoare este:", max)
        if i=='X':
            break
        if i=='3':
            rucsac = Rucsac1("rucsac20")
            rucsac.nahc(10, 5, 10)

        if i=='4':
            rucsac = Rucsac1("rucsac200")
            rucsac.nahc(100, 5, 10)
        if i=='5':
            rucsac=Rucsac3("rucsac20")

            val,valoare,greutate=rucsac.rucsac_tabu_search(9,7)

            print(val,valoare,greutate)

        if i=='6':
            voiajor=Voiajor1("berlin52")
            i=0
            suma=0
            lista=[]
            while i<10:
                b,distanta=voiajor.problema_voiajor(10,5)
                lista.append(distanta)
                suma=suma+distanta
                print("i este",i,b, distanta)
                i=i+1

            min = min(lista)
            medie=suma/10
            print("medie",medie)
            print("min",min)
            print("min/medie",min/medie)







