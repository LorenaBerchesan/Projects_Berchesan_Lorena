import numpy as np


class Rucsac3:
    def __init__(self, filename):
        with open(filename, 'r') as file:
            lines = file.readlines()
            self.size = int(lines[0])
            self.items = []
            for line in lines [ 1:-1 ]:
                l = line.split()
                item = [int(l[0]), int(l[1]), int(l[2])]
                self.items.append(item)
            self.cap = int(lines[-1])
        self.solutie = [0] * self.size


    def generare_solutie_random(self):
        solutie = self.solutie.copy()
        while True:
            el = int(np.random.randint(0, self.size, 1))
            if solutie[el] == 1:
                continue
            greutate = self.generareGreutate(solutie.copy(), el)
            if greutate > self.cap:

                return solutie
            solutie[el] = 1

    def generareGreutate(self,solutie,urmSol=None):
        greutate=0
        if urmSol:
            solutie[urmSol]=1
        for i in range(self.size):
            if solutie[i] == 0:
                continue
            greutate=greutate+ self.items[i][2]
        return greutate



    def generareValoare(self, solutie):
        val = 0
        for i in range(self.size):
            if solutie[i] == 0:
                continue
            val =val+self.items[i][1]
        return val


    def evaluare(self, greutate, vecin, valoare_curenta):

        if greutate < self.cap:
            val = self.generareValoare(vecin)
            if val > valoare_curenta:
                return True
        return False

    def vecini_TS(self, cHT, memorie):
        valoare_curenta = self.generareValoare(cHT)
        j=0
        bHT = cHT
        for i in range(self.size):
            vecin = cHT.copy()

            if vecin[i] == 0:
                vecin[i] = 1
            else:
                vecin[i]=0
            greutate = self.generareGreutate(vecin)
            if vecin not in memorie and self.evaluare(greutate, vecin, valoare_curenta):
                bHT = vecin
                j=j+1
        if j>0:
            memorie.append(bHT)
        return bHT

    def evaluareCandidat(self, cHT, bHT):
        cHT = self.generareValoare(cHT)
        bHT = self.generareValoare(bHT)

        if cHT > bHT:
            return True
        return False

    def rucsac_tabu_search(self, k, marime_memorie):
        cHT = self.generare_solutie_random()
        print("cHT",cHT)
        print("greutate", self.generareGreutate(cHT))
        print("valoare", self.generareValoare(cHT))
        best_ht = cHT.copy()
        memorie = [cHT]

        for i in range(k):
            x = self.vecini_TS(cHT, memorie)
            print(i,"vecini_TS",x)
            print("greutate",self.generareGreutate(x))
            print("valoare",self.generareValoare(x))
            if len(memorie)>marime_memorie:
                memorie.pop(0)

            print(i,"memorie",memorie)

            cHT= x
            if self.evaluareCandidat(cHT, best_ht):
                best_ht = cHT
                print("bestHt",best_ht)
        return best_ht, self.generareValoare(best_ht), self.generareGreutate(best_ht)

