import numpy as np


class Voiajor1:
    def __init__(self, filename):
        with open(filename, 'r') as file:
            lines = file.readlines()
            self.size = int(lines[3].split()[-1])
            self.orase = []
            for line in lines[6:-1]:
                data = line.split()
                oras = [int(data[0]), float(data[1]), float(data[2])]
                self.orase.append(oras)
            self.distanta()
            self.solutie = []

    def euc(self, x, y):
        distanta = np.sqrt((self.orase[y][1] - self.orase[x][1])
                           ** 2 + (self.orase[y][2] - self.orase[x][2])**2)
        return distanta

    def distanta(self):
        self.dist = {}
        for x in range(0, self.size):
            for y in range(x + 1, self.size):
                d = self.euc(int(x), int(y))
                self.dist[(x, y)] = d

    def generate_random_solution(self):
        solutie = []
        while True:
            element = np.random.randint(0, self.size, 1)
            if element not in solutie:
                solutie.append(element[0])
            if len(solutie) == self.size:
                break
        return solutie, self.evaluare(solutie)

    def evaluare(self, solutie):
        dist = 0
        for i in range(1,len(solutie)):
            oras1 = solutie[i - 1]
            oras2 = solutie[i]
            if oras1 < oras2:
                orase = (oras1, oras2)
            else:
                orase = (oras2,oras1)
            dist =dist+ self.dist[orase]
        return dist

    def vecini(self, element, tabu):
        vecinatate = []
        for i in range(0, self.size):
            for j in range(i + 1, self.size):
                vecin = element.copy()
                vecin[i], vecin[j] = vecin[j], vecin[i]
                vecinatate.append(vecin)
        bC = vecinatate[0]
        bC_distanta = self.evaluare(bC)
        for candidate in vecinatate:
            candidat_distanta = self.evaluare(candidate)
            if candidate not in tabu and candidat_distanta < bC_distanta:
                bC = candidate
                bC_distanta = candidat_distanta
        return bC, bC_distanta

    def problema_voiajor(self, k, tabu_size):
        bC, bC_distanta = self.generate_random_solution()
        b = bC.copy()
        bD = bC_distanta
        tabu = []
        tabu.append(bC)
        for i in range(k):
            bV, bV_distanta = self.vecini(bC, tabu)
            tabu.append(bV)
            if len(tabu) > tabu_size:
                tabu.pop(0)
            bC, bC_distanta = bV, bV_distanta
            if bD > bC_distanta:
                b = bC
        return b, bD
